﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ScadaModels
{
    [DataContract]
    public class DI : InTag
    {
        //public DI(string name, string description, IDriver driver, string ioaddress, int scanTime, bool scanEnabled) : base(name, description, driver, ioaddress, scanTime, scanEnabled) { }
    }
}
