﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseManager
{
    public class DatabaseManager
    {
        public void ChangeOutputValue() { }
        public float GetOutputValue() { return 0; }
        public void TurnScanOn() { }
        public void TurnScanOff() { }
        public void AddTag() { }
        public void RemoveTag() { }
        public void Login() { }
        public void Logout() { }
        public void Register() { }
    }
}